<?php
$lang->cash->menuOrder[5]  = 'dashboard';
$lang->cash->menuOrder[10] = 'all';
$lang->cash->menuOrder[15] = 'in';
$lang->cash->menuOrder[20] = 'out';
$lang->cash->menuOrder[25] = 'transfer';
$lang->cash->menuOrder[30] = 'invest';
$lang->cash->menuOrder[35] = 'loan';
$lang->cash->menuOrder[40] = 'check';
$lang->cash->menuOrder[45] = 'report';
$lang->cash->menuOrder[50] = 'depositor';
$lang->cash->menuOrder[55] = 'provider';
$lang->cash->menuOrder[60] = 'setting';

$lang->provider->menuOrder[5] = 'browse';

$lang->contact->menuOrder[5] = 'browse';

$lang->report->menuOrder[5]  = 'annual';
$lang->report->menuOrder[10] = 'compare';
$lang->report->menuOrder[15] = 'export';

$lang->setting->menuOrder[5]  = 'income';
$lang->setting->menuOrder[10] = 'expend';
$lang->setting->menuOrder[15] = 'currency';
$lang->setting->menuOrder[20] = 'schema';
$lang->setting->menuOrder[25] = 'tradePriv';
$lang->setting->menuOrder[30] = 'tradeSetting';
