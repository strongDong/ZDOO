<?php
$lang->attend->clientList['xuanxuan'] = '喧喧';
