$(document).ready(function()
{
    setType(v.type);
});
