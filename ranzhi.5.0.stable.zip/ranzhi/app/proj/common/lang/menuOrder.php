<?php
$lang->proj->menuOrder[5]  = 'dashboard';
$lang->proj->menuOrder[10] = 'involved';
$lang->proj->menuOrder[15] = 'doing';
$lang->proj->menuOrder[20] = 'finished';
$lang->proj->menuOrder[25] = 'suspend';
